Place logo.png and screenshot-1.png ... here.
